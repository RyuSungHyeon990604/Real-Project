import { Calender } from "./component/Calendar";

const App = () => {
  return(
    <main>
    <Calender />
    </main>
  );
  };

export default App;